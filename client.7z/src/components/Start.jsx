export default function Start () {
	return (
		<div className="start-page">
			<h1>Добро пожаловать!</h1>
			<p>Скоро будет доступен <br /> первый вопрос.</p>
		</div>
	)
}